WEDE5020 PEO - Part 1

Elite Euro Auto Services Website 

Student information 
-Name: Kamohelo Mosia
-Student Number: [ST10476147]
-Module: [WEDE5020]

Project Oveerview
The project is about the development and planning of creating a website for companies using html and the structure before the css

Website gosls and objectives
-Ensure responsive design across devices for a user friendly experience 
-Provide accessible information to users through concise and straightforward content
-Showcase services and engage with the community to built brand awareness
-Increase visibilty and establish a strong online presence 

Key features and functionality
-A dedication form for users to submit service requests efficiently
-A user friendly homepage with a navigation bar for easy exploration 
-An embedded map to help users find your physical location
-A contact form with email intergration for seamless communication

Timeline and Milestones 
-week 1-2: Planninng and research
-week 3-4: Design and wireframes
-week 5: Development
-week 6: Feedback and Testing

Part 1 Details:
includes:
-Project proposal
-Sitemap
-Initial wireframes
-Basic navigation and layout

Part 2 
includes:
-CSS and all styles
-Improved and New navigation bar
-More appealing website

Refences 
Mechanics Workshop Car Diagnostics Equipment. Available at: https://pngtree.com/freebackground/mechanics-workshop-car-diagnostics-equipment_16391411.html (Accessed: 25 september 2025).

Car diagnostics / diagnostic tool setup. Available at: https://www.valleychevy.com/what-is-a-car-diagnostic-test/ (Accessed: 25 september 2025).


Mechanic using diagnostic tablet on car. Available at: https://cardiagnosis.hatenablog.com/ (Accessed: 25 september 2025).


Diagnostic interface / software on car. Available at: https://www.dubizzle.com/blog/cars/car-diagnostic-tool-guide/ (Accessed: 25 september 2025).

